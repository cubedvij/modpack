Requires ModLoader, Forge and Aether.

-Pistons can now be mined at propert speed by forge tools.
-Pistons can't push unbreakable blocks from other mods.
-Pistons can't push Aether bosses.
-Patched a duplication glitch.

Made by Meefy