package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.awt.Color;
import java.util.Properties;
import net.minecraft.client.Minecraft;

public class mod_Tooltip extends BaseMod
{

    public String Version()
    {
        return "r3";
    }

    public mod_Tooltip()
    {
        ModLoader.SetInGameHook(this, true, false);
    }

    private static void prepareConfig()
    {
        ModSettings modsettings = new ModSettings("Tooltip");
        ModSettingScreen modsettingscreen = new ModSettingScreen("Tooltip");
        optionEnabled = modsettings.addSetting(modsettingscreen, "Enabled", "enabled", true);
        optionPosition = modsettings.addSetting(modsettingscreen, "Position", "position", 1, new String[] {
            "Top left", "Top right", "Bottom left", "Bottom right"
        });
        modsettings.load();
    }

    public boolean OnTickInGame(Minecraft minecraft)
    {
        if(getEnabled())
        {
            ScaledResolution scaledresolution = new ScaledResolution(minecraft.gameSettings, minecraft.displayWidth, minecraft.displayHeight);
            int i = scaledresolution.getScaledWidth();
            int j = scaledresolution.getScaledHeight();
            int k = 2;
            int l = 2;
            byte byte0 = 10;
            boolean flag = false;
            int i1 = getPosition();
            if(i1 == 2 || i1 == 3)
            {
                l = j - 10;
                byte0 = -10;
            }
            if(i1 == 1 || i1 == 3)
            {
                k = i - 2;
                flag = true;
            }
            ItemStack itemstack = getPlayerItemInHand(minecraft);
            if(itemstack != null && itemstack.stackSize > 0)
            {
                String s = getTooltip(itemstack);
                String s1 = "";
                if(!s.equals(""))
                {
                    if(itemstack.stackSize > 1)
                    {
                        s = (new StringBuilder(String.valueOf(itemstack.stackSize))).append("x ").append(s).toString();
                    }
                    minecraft.fontRenderer.drawStringWithShadow(s, k - (flag ? minecraft.fontRenderer.getStringWidth(s) : 0), l, (new Color(255, 255, 255)).getRGB());
                    l += byte0;
                }
                if(itemstack.itemID > 255 && !itemstack.getItem().hasSubtypes && itemstack.getItemDamage() > 0)
                {
                    String s2 = (new StringBuilder(String.valueOf((itemstack.getItem().getMaxDamage() - itemstack.getItemDamage()) + 1))).append("/").append(itemstack.getItem().getMaxDamage() + 1).toString();
                    minecraft.fontRenderer.drawStringWithShadow(s2, k - (flag ? minecraft.fontRenderer.getStringWidth(s2) : 0), l, (new Color(255, 255, 255)).getRGB());
                }
            }
        }
		return true;
    }

    private static boolean getEnabled()
    {
        if(usingGUIAPI)
        {
            return (Boolean) ((SettingBoolean)optionEnabled).get();
        } else
        {
            return true;
        }
    }

    private static int getPosition()
    {
        if(usingGUIAPI)
        {
            return (Integer) ((SettingMulti)optionPosition).get();
        } else
        {
            return 1;
        }
    }

    private static ItemStack getPlayerItemInHand(Minecraft minecraft)
    {
        if(minecraft.thePlayer != null && minecraft.thePlayer.inventory != null)
        {
            return minecraft.thePlayer.inventory.getCurrentItem();
        } else
        {
            return null;
        }
    }

    private static String getTooltip(ItemStack itemstack)
    {
        try
        {
            String s = ((Properties)ModLoader.getPrivateValue(StringTranslate.class, StringTranslate.getInstance(), 1)).getProperty((new StringBuilder(String.valueOf(itemstack.getItemName()))).append(".name").toString());
            return s != null ? s : "";
        }
        catch(IllegalArgumentException illegalargumentexception) { }
        catch(SecurityException securityexception) { }
        catch(NoSuchFieldException nosuchfieldexception) { }
        return "";
    }

    private static boolean usingGUIAPI = false;
    private static Object optionEnabled;
    private static Object optionPosition;

    static 
    {
        try
        {
            Class.forName("ModSettings");
            usingGUIAPI = true;
            prepareConfig();
        }
        catch(ClassNotFoundException classnotfoundexception) { }
    }
}
