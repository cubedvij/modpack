Requires ModLoader
GuiAPI Optional for in-game changing of settings