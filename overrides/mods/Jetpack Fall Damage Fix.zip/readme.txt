Stops all fall damage when player is wearing Jetpack or Electric Jetpack on chest.

Made for IC2 by Meefy