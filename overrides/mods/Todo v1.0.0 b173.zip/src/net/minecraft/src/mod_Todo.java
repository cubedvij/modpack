package net.minecraft.src;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import todo.GuiTodo;
import todo.Page;

public class mod_Todo extends BaseMod {
	public static List<Page> pages = new ArrayList<>();
	private final KeyBinding key_todo = new KeyBinding("key.todo", Keyboard.KEY_M);

	public mod_Todo() {
		ModLoader.RegisterKey(this, this.key_todo, false);
		ModLoader.AddLocalization("key.todo", "To-Do List");
		ModLoader.SetInGameHook(this, true, false);
	}

	public static void write() throws IOException {
		NBTTagCompound rootTag = new NBTTagCompound();
		NBTTagList pagesList = new NBTTagList();

		for (Page page : pages) {
			NBTTagCompound pageTag = new NBTTagCompound();
			NBTTagList lines = new NBTTagList();

			for (String line : page.lines) {
				lines.setTag(new NBTTagString(line));
			}

			pageTag.setTag("lines", lines);

			NBTTagByte checkboxes = new NBTTagByte(page.checkboxes);
			pageTag.setTag("checkboxes", checkboxes);

			pagesList.setTag(pageTag);
		}
		rootTag.setTag("pages", pagesList);

		File file = new File(((SaveHandler) ModLoader.getMinecraftInstance().theWorld.saveHandler).getSaveDirectory(), "todo.dat");
		CompressedStreamTools.writeGzippedCompoundToOutputStream(rootTag, Files.newOutputStream(file.toPath()));
	}

	public static void read() throws IOException {
		File file = new File(((SaveHandler) ModLoader.getMinecraftInstance().theWorld.saveHandler).getSaveDirectory(), "todo.dat");
		NBTTagCompound rootTag = CompressedStreamTools.func_1138_a(Files.newInputStream(file.toPath()));

		NBTTagList pagesList = rootTag.getTagList("pages");

		for (int page = 0; page < pagesList.tagCount(); page++) {
			NBTTagCompound pageCompound = (NBTTagCompound) pagesList.tagAt(page);

			byte checkboxes = pageCompound.getByte("checkboxes");

			NBTTagList linesList = pageCompound.getTagList("lines");
			List<String> lines = new ArrayList<>();
			for (int line = 0; line < 6; line++) {
				NBTTagString lineString = (NBTTagString) linesList.tagAt(line);
				lines.add(lineString.stringValue);
			}

			pages.add(page, new Page(page, checkboxes, lines));
		}
	}

	public void KeyboardEvent(KeyBinding event) {
		Minecraft mc = ModLoader.getMinecraftInstance();

		if (event == this.key_todo && ModLoader.isGUIOpen(null)) {
			ModLoader.OpenGUI(mc.thePlayer, new GuiTodo());
		}
	}

	public String Version() {
		return "v1.0.0";
	}

	public static void addPage(Page page) {
		pages.add(page);
    }

	public static Page getPage(int i) {
		if (i >= pages.size()) {
			List<String> lines = new ArrayList<>();
			for (int strings = 0; strings < 6; strings++) {
				lines.add("");
			}

			Page newPage = new Page(i, (byte) 0, lines);
			addPage(newPage);
			return newPage;
		} else {
			return pages.get(i);
		}
	}
}
