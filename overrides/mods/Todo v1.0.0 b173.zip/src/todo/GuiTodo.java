package todo;

import net.minecraft.src.GuiScreen;
import net.minecraft.src.GuiTextField;
import net.minecraft.src.mod_Todo;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.io.IOException;

public class GuiTodo extends GuiScreen {
	int xSize = 176;
	int ySize = 166;
	private GuiTextField textField;
	private Page currentPage;
	private int selectedList;
	private boolean hasBeenRead;

	@Override
	public void initGui() {
		try {
			mod_Todo.read();
		} catch (IOException e) {
			System.err.println("[TODO LIST] Error reading todo.dat!\n" + e);
		}

		Keyboard.enableRepeatEvents(true);
		this.controlList.clear();
		textField = new GuiTextField(this, fontRenderer, (width - xSize) / 2 - 10, (height - ySize) / 2 - 24, 200, 20, "");
		textField.setMaxStringLength(20);
		currentPage = mod_Todo.getPage(0);
		selectedList = 0;
	}

	public void drawScreen(int i, int j, float k) {
		int x = (width - xSize) / 2;
		int y = (height - ySize) / 2;

		drawDefaultBackground();
		int texture = mc.renderEngine.getTexture("/gui/todo.png");
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(texture);
		drawTexturedModalRect(x, y, 0, 0, xSize, ySize);

		// Checkmarks
		for (int check = 0; check < 6; check++) {
			drawTexturedModalRect(x + 16, y + 16 + (18 * check), 176, 0, 16, 16);
		}
		if (currentPage.isFirstChecked()) {
			drawTexturedModalRect(x + 16, y + 16, 192, 0, 16, 16);
		}
		if (currentPage.isSecondChecked()) {
			drawTexturedModalRect(x + 16, y + 34, 192, 0, 16, 16);
		}
		if (currentPage.isThirdChecked()) {
			drawTexturedModalRect(x + 16, y + 52, 192, 0, 16, 16);
		}
		if (currentPage.isFourthChecked()) {
			drawTexturedModalRect(x + 16, y + 70, 192, 0, 16, 16);
		}
		if (currentPage.isFifthChecked()) {
			drawTexturedModalRect(x + 16, y + 88, 192, 0, 16, 16);
		}
		if (currentPage.isSixthChecked()) {
			drawTexturedModalRect(x + 16, y + 106, 192, 0, 16, 16);
		}

		// Page Buttons
		drawTexturedModalRect(x + 32, y + 128, 208, 0, 16, 16);
		drawTexturedModalRect(x + 128, y + 128, 224, 0, 16, 16);

		// Page Text
		fontRenderer.drawStringWithShadow("Page " + currentPage.id, x + 70, y + 130, -1);

		for (int loop = 0; loop < 6; loop++) {
			fontRenderer.drawString(currentPage.getLine(loop), x + 34, y + 22 + (18 * loop), 0x99876c);
		}

		if (textField.isFocused) {
			textField.drawTextBox();
		}
	}

	protected void mouseClicked(int mouseX, int mouseY, int m) {
		if (!textField.isFocused) {
			super.mouseClicked(mouseX, mouseY, m);
			int x = (width - xSize) / 2;
			int y = (height - ySize) / 2;

			for (int i = 0; i < 6; i++) {
				if (mouseX >= x + 32 && mouseX < x + 160) {
					if (mouseY >= y + 16 + (18 * i) && mouseY < y + 32 + (18 * i)) {
						textField.setFocused(true);
					}
				}
			}

			mouseClickedSlot(mouseX, mouseY);
			mouseClickedBox(mouseX, mouseY);

			// Page Back
			if (mouseX >= x + 32 && mouseX < x + 48) {
				if (mouseY >= y + 128 && mouseY < y + 144) {
					if (currentPage.id - 1 >= 0) {
						currentPage = mod_Todo.getPage(currentPage.id - 1);
					}
				}
			}

			// Page forward
			if (mouseX >= x + 128 && mouseX < x + 144) {
				if (mouseY >= y + 128 && mouseY < y + 144) {
					currentPage = mod_Todo.getPage(currentPage.id + 1);
				}
			}
		}
	}

	private void mouseClickedBox(int mouseX, int mouseY) {
		int x = (width - xSize) / 2;
		int y = (height - ySize) / 2;

		if (mouseX >= x + 16 && mouseX < x + 32) {
			if (mouseY >= y + 16 && mouseY < y + 34) {
				if (!currentPage.isFirstChecked()) {
					currentPage.setFirstChecked(true);
				} else {
					currentPage.setFirstLine("");
					currentPage.setFirstChecked(false);
				}
			} else if (mouseY >= y + 34 && mouseY < y + 52) {
				if (!currentPage.isSecondChecked()) {
					currentPage.setSecondChecked(true);
				} else {
					currentPage.setSecondLine("");
					currentPage.setSecondChecked(false);
				}
			} else if (mouseY >= y + 52 && mouseY < y + 70) {
				if (!currentPage.isThirdChecked()) {
					currentPage.setThirdChecked(true);
				} else {
					currentPage.setThirdLine("");
					currentPage.setThirdChecked(false);
				}
			} else if (mouseY >= y + 70 && mouseY < y + 88) {
				if (!currentPage.isFourthChecked()) {
					currentPage.setFourthChecked(true);
				} else {
					currentPage.setFourthLine("");
					currentPage.setFourthChecked(false);
				}
			} else if (mouseY >= y + 88 && mouseY < y + 106) {
				if (!currentPage.isFifthChecked()) {
					currentPage.setFifthChecked(true);
				} else {
					currentPage.setFifthLine("");
					currentPage.setFifthChecked(false);
				}
			} else if (mouseY >= y + 106 && mouseY < y + 124) {
				if (!currentPage.isSixthChecked()) {
					currentPage.setSixthChecked(true);
				} else {
					currentPage.setSixthLine("");
					currentPage.setSixthChecked(false);
				}
			}
		}
	}

	private void mouseClickedSlot(int mouseX, int mouseY) {
		int x = (width - xSize) / 2;
		int y = (height - ySize) / 2;

		if (mouseX >= x + 32 && mouseX < x + 160) {
			if (mouseY >= y + 16 && mouseY < y + 34) {
				selectedList = 0;
			} else if (mouseY >= y + 34 && mouseY < y + 52) {
				selectedList = 1;
			} else if (mouseY >= y + 52 && mouseY < y + 70) {
				selectedList = 2;
			} else if (mouseY >= y + 70 && mouseY < y + 88) {
				selectedList = 3;
			} else if (mouseY >= y + 88 && mouseY < y + 106) {
				selectedList = 4;
			} else if (mouseY >= y + 106 && mouseY < y + 124) {
				selectedList = 5;
			}
		}
	}

	public boolean doesGuiPauseGame() {
		return false;
	}

	@Override
	protected void keyTyped(char keycode, int i) {
		if (textField.isFocused) {
			textField.textboxKeyTyped(keycode, i);

			if(keycode == 13) {
				currentPage.setLine(selectedList, textField.getText());
				textField.setFocused(false);
				textField.setText("");
			}
		} else {
			super.keyTyped(keycode, i);
		}
	}

	@Override
	public void onGuiClosed() {
		try {
			mod_Todo.write();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		mod_Todo.pages.clear();

		Keyboard.enableRepeatEvents(false);
	}

	@Override
	public void updateScreen() {
	}
}
